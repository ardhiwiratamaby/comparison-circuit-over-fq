export NTL_LIBRARY=/home/ardhy/helib_install/helib_pack/lib
export NTL_INCLUDE_DIR=/home/ardhy/helib_install/helib_pack/include/NTL
