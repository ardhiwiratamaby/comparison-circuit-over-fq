#!/usr/bin/env bash

rm -f CMakeCache.txt
rm -rf CMakeFiles
rm -f cmake_install.cmake
